import React from 'react'

const Navbar = () => {
  return (
    <div>Logo</div>
  )
}

export default Navbar